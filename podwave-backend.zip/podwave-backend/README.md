# PodWave Backend

Unified audio API for a web music / podcast player: **one normalized track shape**, three legal catalogs, and a Range-aware stream proxy so an HTML5 `<audio>` element just works.

```
podcasts  ->  PodcastIndex  (SHA1-signed, returns mp3 enclosures)
          ->  ListenNotes   (X-ListenAPI-Key, best episode search)
          ->  plain RSS     (no key at all, <enclosure url="...mp3">)
music     ->  Jamendo       (client_id, full-length legal mp3)
          ->  Spotify       (metadata + 30s previews only)
youtube   ->  Data API v3   (search + metadata, playback via official embed)
```

---

## 1. Install & run

```bash
cd podwave-backend
npm install
cp .env.example .env       # add whichever keys you have; all are optional
npm start                  # http://localhost:8080
```

Open `http://localhost:8080/demo` for a working player that exercises every route.

Check what is live:

```bash
curl http://localhost:8080/api/providers
```

```json
{
  "ok": true,
  "providers": { "podcastindex": true, "listennotes": false, "jamendo": true, "youtube": true, "rss": true },
  "streamProxy": true,
  "cache": { "entries": 0, "hits": 0, "misses": 0, "hitRate": 0 }
}
```

---

## 2. Where the keys come from

| Provider | Register | Auth mechanism | Cost |
|---|---|---|---|
| PodcastIndex | https://api.podcastindex.org/signup | `X-Auth-Key` + `X-Auth-Date` + `Authorization: sha1(key+secret+date)` | free |
| ListenNotes | https://www.listennotes.com/api/pricing/ | `X-ListenAPI-Key` header | free tier ≈300 req/mo |
| Jamendo | https://devportal.jamendo.com | `client_id` query param | free |
| YouTube Data API v3 | https://console.cloud.google.com/apis/credentials | `key` query param | free quota |
| Spotify | https://developer.spotify.com/dashboard | Client Credentials → Bearer token | free, previews only |

PodcastIndex signing is implemented in `src/providers/podcastindex.js`:

```js
const unixTime = Math.floor(Date.now() / 1000);
const authorization = crypto.createHash('sha1')
  .update(`${apiKey}${apiSecret}${unixTime}`)
  .digest('hex');

headers = { 'X-Auth-Key': apiKey, 'X-Auth-Date': String(unixTime), Authorization: authorization };
```

Headers are regenerated per request, so the timestamp never goes stale.

---

## 3. API surface

### Search everything at once
```
GET /api/search?q=lofi&sources=podcasts,music,youtube&limit=20
```

```json
{
  "ok": true,
  "source": "aggregate",
  "query": "lofi",
  "count": 42,
  "tracks": [ { "...normalized track..." } ],
  "bySource": { "listennotes": 20, "jamendo": 20, "youtube": 2 },
  "errors": [],
  "notices": [{ "source": "spotify", "message": "Spotify results are 30-second previews" }]
}
```

Per-source variants: `/api/search/podcasts`, `/api/search/music` (`?tags=chill,acoustic`), `/api/search/youtube`.

### Podcasts
```
GET /api/podcasts/search?q=history
GET /api/podcasts/podcastindex/920666/episodes?limit=20
GET /api/podcasts/listennotes/<id>/episodes
GET /api/rss?url=https://feeds.simplecast.com/54nAGcIl&limit=20
GET /api/rss/discover?url=https://example.com/showname
```

### Single track / resolving links
```
GET /api/track/jamendo:1234567
GET /api/tracks/youtube/dQw4w9WgXcQ
GET /api/resolve?url=https://youtu.be/dQw4w9WgXcQ
GET /api/resolve?url=https://cdn.example.com/audio/ep1.mp3
```

### Stream proxy
```
GET /api/stream?url=<url-encoded audio url>
```
Forwards `Range` (so seeking works), sets `Accept-Ranges`, `Content-Range`, `Access-Control-Allow-Origin: *`, and fixes http→https mixed content. Private IPs and metadata endpoints are blocked (SSRF guard); `STREAM_ALLOWED_HOSTS` narrows it further.

### Ops
```
GET /health
GET /api
GET /api/providers
```

---

## 4. The normalized track (one shape for every source)

```json
{
  "id": "jamendo:1234567",
  "source": "jamendo",
  "kind": "music",
  "title": "Track name",
  "subtitle": "Album name",
  "artist": "Artist",
  "album": "Album",
  "artwork": { "small": "https://...", "medium": "https://...", "large": "https://..." },
  "durationSec": 214,
  "durationLabel": "3:34",
  "publishedAt": "2024-05-01T00:00:00.000Z",
  "audioUrl": "https://prod-1.storage.jamendo.com/?trackid=...&format=mp32",
  "proxyUrl": "/api/stream?url=https%3A%2F%2Fprod-1.storage.jamendo.com%2F...",
  "downloadUrl": null,
  "embedUrl": null,
  "playable": true,
  "isPreview": false,
  "explicit": false,
  "language": "en",
  "license": "https://creativecommons.org/licenses/by-nc-nd/3.0/",
  "links": { "self": "/api/tracks/jamendo/1234567", "webpage": "https://www.jamendo.com/track/1234567" },
  "meta": { "jamendoId": "1234567", "audiodownloadAllowed": false }
}
```

`audioUrl` is always what `<audio>` should load. For YouTube rows `audioUrl` is `null`, `embedUrl` is set, and `playable` is still `true`.

---

## 5. Frontend usage

```html
<audio id="player" preload="metadata" controls></audio>

<script type="module">
const player = document.getElementById('player');
const API = 'http://localhost:8080';

// 1. search -> take the first playable row
const res = await fetch(`${API}/api/search?q=lofi&sources=music`);
const { tracks } = await res.json();
const track = tracks.find((t) => t.playable && t.audioUrl);

// 2. point <audio> at the proxy (CORS + Range safe)
player.src = `${API}${track.proxyUrl}`;
await player.play();

// 3. YouTube rows are embedded instead
// <iframe allow="autoplay" src={track.embedUrl}>
</script>
```

Queue / next-track logic is plain data: keep the `tracks` array, advance an index, reassign `player.src`. `durationSec` is known up front for podcast/YouTube rows, so you can render a seek bar before metadata loads.

---

## 6. Project layout

```
server.js                    express app, CORS, rate limit, error envelope
src/config.js                env parsing + provider availability
src/cache.js                 TTL cache with in-flight de-dup
src/http.js                  fetchJson (timeout, retry, UpstreamError)
src/normalize.js             makeTrack / parseDuration / stripHtml / envelope
src/providers/podcastindex.js  SHA1 auth, feeds, episodes, episode search
src/providers/listennotes.js   X-ListenAPI-Key, episode + podcast search
src/providers/rss.js           RSS/Atom parser -> mp3 enclosures
src/providers/jamendo.js       free full-length mp3
src/providers/spotify.js       client credentials, previews only
src/providers/youtube.js       search + metadata, embed URLs, id extraction
src/routes/search.js           aggregate + per-source search
src/routes/podcasts.js         podcast grids, episodes, raw RSS
src/routes/tracks.js           single track, resolve, /providers
src/routes/stream.js           Range-aware SSRF-guarded proxy
public/index.html              demo player
```

---

## 7. Why there is no YouTube → MP3 route

YouTube's Terms of Service prohibit downloading or separating the audio track from a video. The Data API v3 is used here strictly for `search.list` (metadata) and `videos.list` (durations, statistics). Playback is delivered through the official IFrame embed (`https://www.youtube.com/embed/<id>`), which is the supported integration.

`yt-dlp` and the "YouTube to MP3" endpoints on RapidAPI are therefore not implemented. If you add them yourself, expect: broken IPs and constant signature changes, DMCA takedowns, and blocked AdSense/payment processing.

The same reasoning applies to the JioSaavn / Gaana scrapers — the scraping repos break whenever the host rotates its signing code, and hosting them is copyright infringement.

---

## 8. Production notes

- **Cache**: in-process TTL only. Multi-instance deploys should swap `src/cache.js` for Redis; `cache.wrap()` already collapses concurrent duplicate requests.
- **Rate limit**: 60 req/min/IP, audio proxy exempt (excluded because a seek-heavy session looks like abuse).
- **Quota math**: ListenNotes free tier is ~300 requests/month, so `CACHE_TTL_SEARCH=300` or higher matters; the aggregate endpoint is one upstream call per source, not per result.
- **`isPreview`**: always check it before showing a "download" button — Spotify rows are 30s clips.
- **CORS**: set `CORS_ORIGINS` to your real frontend origins in production, not `*`.

---

## 9. Smoke test

```bash
npm start &
curl -s localhost:8080/health
curl -s "localhost:8080/api/search?q=lofi&sources=music,youtube"
curl -s "localhost:8080/api/rss?url=https://feeds.simplecast.com/54nAGcIl&limit=3"
curl -s "localhost:8080/api/providers"
```

Without any API keys, `/health` and `/api/providers` respond and search returns `errors[]` naming exactly which key is missing — the server never crashes on an unconfigured provider.
