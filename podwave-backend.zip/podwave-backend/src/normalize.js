/**
 * One normalized shape for every playable thing, whatever the source.
 *
 * Frontend can therefore do: `audioEl.src = track.audioUrl` for every result,
 * with no per-source branching. Provider files are responsible for mapping
 * their raw payloads into this shape via the helpers below.
 */

export const SOURCES = ['podcastindex', 'listennotes', 'jamendo', 'spotify', 'rss', 'youtube'];
export const KINDS = ['podcast', 'music', 'youtube'];

const text = (value) => (typeof value === 'string' ? value.trim() : '');
const firstString = (...values) => values.map(text).find(Boolean) || '';

/** "1:02:03" | "45:10" | 3725 | "3725" -> seconds. Returns 0 when unknown. */
export function parseDuration(value) {
  if (typeof value === 'number' && Number.isFinite(value)) return Math.max(0, Math.round(value));
  const raw = text(String(value ?? ''));
  if (!raw) return 0;
  if (raw.includes(':')) {
    const parts = raw.split(':').map((part) => Number.parseInt(part, 10)).filter(Number.isFinite);
    return parts.reduce((total, part) => total * 60 + part, 0);
  }
  const plain = Number.parseFloat(raw);
  return Number.isFinite(plain) ? Math.max(0, Math.round(plain)) : 0;
}

/** Podcast/RSS dates come as RFC-822 strings, epoch seconds, or epoch ms. */
export function toIso(value) {
  if (value === null || value === undefined || value === '') return null;
  if (typeof value === 'number' || /^\d+$/.test(String(value))) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric) || numeric <= 0) return null;
    const ms = numeric > 1e12 ? numeric : numeric * 1000;
    const date = new Date(ms);
    return Number.isNaN(date.getTime()) ? null : date.toISOString();
  }
  const date = new Date(String(value));
  return Number.isNaN(date.getTime()) ? null : date.toISOString();
}

/** Absolute-ise artwork, upgrade known size tokens, reject junk. */
export function artworkFrom(...candidates) {
  for (const candidate of candidates.flat()) {
    const url = text(candidate);
    if (!url) continue;
    if (!/^https?:\/\//i.test(url) && !url.startsWith('data:image')) continue;
    // Jamendo: .../covers/500?imagesize=500 -> keep 500 for retina-ish quality.
    const upgraded = url
      .replace(/imagesize=\d+/, 'imagesize=500')
      .replace(/\/covers\/(\d+)\?/, '/covers/500?');
    return {
      small: upgraded,
      medium: upgraded,
      large: upgraded,
    };
  }
  return { small: null, medium: null, large: null };
}

export function isPlayableUrl(url) {
  const value = text(url);
  if (!value) return false;
  if (!/^https?:\/\//i.test(value)) return false;
  // Media enclosures, not HTML pages.
  return /\.(mp3|m4a|aac|ogg|oga|opus|wav|flac|m4b|mp4|webm)(\?|#|$)/i.test(value) || /\/stream\b/i.test(value) || /audio/i.test(value);
}

/**
 * The canonical track object.
 * `audioUrl` is always what <audio> should load; `proxyUrl` is the
 * CORS/mixed-content-safe alternative served from /api/stream.
 */
export function makeTrack({
  id,
  source,
  kind,
  title,
  subtitle = '',
  artist = '',
  album = '',
  artwork = {},
  durationSec = 0,
  publishedAt = null,
  audioUrl = null,
  downloadUrl = null,
  videoUrl = null,
  embedUrl = null,
  isPreview = false,
  explicit = false,
  language = null,
  license = null,
  links = {},
  meta = {},
}) {
  const playable = Boolean(audioUrl) || Boolean(embedUrl);
  return {
    id,
    source,
    kind,
    title: title || 'Untitled',
    subtitle,
    artist,
    album,
    artwork,
    durationSec: Number.isFinite(durationSec) ? durationSec : 0,
    durationLabel: formatDuration(durationSec),
    publishedAt,
    audioUrl: audioUrl || null,
    proxyUrl: audioUrl ? `/api/stream?url=${encodeURIComponent(audioUrl)}` : null,
    downloadUrl: downloadUrl || null,
    videoUrl: videoUrl || null,
    embedUrl: embedUrl || null,
    playable,
    isPreview: Boolean(isPreview),
    explicit: Boolean(explicit),
    language: language || null,
    license: license || null,
    links,
    meta,
  };
}

export function formatDuration(seconds) {
  const total = Math.max(0, Math.round(Number(seconds) || 0));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (n) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}

/** Strip HTML so descriptions are safe to drop straight into a <p>. */
export function stripHtml(input, maxLength = 600) {
  const raw = String(input ?? '');
  if (!raw) return '';
  const withoutTags = raw
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/\s+/g, ' ')
    .trim();
  if (withoutTags.length <= maxLength) return withoutTags;
  return `${withoutTags.slice(0, maxLength).trimEnd()}…`;
}

export function makePagination({ total = 0, limit = 20, offset = 0 }) {
  const hasMore = offset + limit < total;
  return {
    total,
    limit,
    offset,
    hasMore,
    nextOffset: hasMore ? offset + limit : null,
  };
}

/** Uniform envelope so the frontend has one parser. */
export function makeResponse({ source, kind, query, tracks, total, limit, offset, cached = false, notice = null }) {
  return {
    ok: true,
    source,
    kind,
    query: query ?? null,
    count: tracks.length,
    pagination: makePagination({ total: total ?? tracks.length, limit, offset }),
    cached,
    notice,
    tracks,
  };
}
