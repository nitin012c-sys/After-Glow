import { Router } from 'express';
import { BadRequestError } from '../http.js';
import { makeResponse } from '../normalize.js';
import * as jamendo from '../providers/jamendo.js';
import * as youtube from '../providers/youtube.js';
import * as listennotes from '../providers/listennotes.js';
import * as podcastindex from '../providers/podcastindex.js';
import * as spotify from '../providers/spotify.js';
import { providerStatus } from '../config.js';

export const searchRouter = Router();

const SOURCE_ALIASES = {
  podcast: 'podcasts',
  podcasts: 'podcasts',
  listennotes: 'podcasts',
  podcastindex: 'podcasts',
  music: 'music',
  jamendo: 'music',
  spotify: 'music',
  youtube: 'youtube',
  yt: 'youtube',
};

const parseSources = (raw) => {
  const requested = String(raw || 'podcasts,music,youtube')
    .split(',')
    .map((item) => SOURCE_ALIASES[item.trim().toLowerCase()])
    .filter(Boolean);
  return [...new Set(requested)];
};

/* ------------------------------------------------------------------ *
 * GET /api/search?q=...&sources=podcasts,music,youtube&limit=20
 *
 * One call, one envelope, three catalogs. Each source is isolated with
 * Promise.allSettled so a dead/ unconfigured provider degrades to an
 * `errors[]` entry instead of a 500 for the whole request.
 * ------------------------------------------------------------------ */
searchRouter.get('/search', async (req, res, next) => {
  try {
    const q = String(req.query.q ?? '').trim();
    const limit = Math.min(Math.max(Number.parseInt(req.query.limit ?? '20', 10) || 20, 1), 50);
    const sources = parseSources(req.query.sources);

    if (!q && !req.query.tags) {
      throw new BadRequestError('Provide a search term: /api/search?q=your+query');
    }

    // Each entry records its own source name so a rejection can still be
    // attributed to the right catalog in errors[] below.
    const jobs = [];
    const wantPodcasts = sources.includes('podcasts');
    const wantMusic = sources.includes('music');
    const wantYoutube = sources.includes('youtube');

    if (wantPodcasts) {
      // ListenNotes gives true episode-level search. PodcastIndex can also do it
      // but needs a feed fan-out, so it is the fallback when LN has no key.
      if (providerStatus().listennotes) {
        jobs.push({ source: 'listennotes', run: () => listennotes.searchEpisodes({ q, limit }) });
      } else if (providerStatus().podcastindex) {
        jobs.push({ source: 'podcastindex', run: () => podcastindex.searchEpisodes({ q, limit }) });
      }
    }

    if (wantMusic) {
      if (providerStatus().jamendo) {
        jobs.push({ source: 'jamendo', run: () => jamendo.search({ q, limit, tags: [] }) });
      }
      if (spotify.isConfigured()) {
        jobs.push({ source: 'spotify', run: () => spotify.search({ q, limit }) });
      }
    }

    if (wantYoutube && providerStatus().youtube) {
      jobs.push({ source: 'youtube', run: () => youtube.search({ q, limit }) });
    }

    const settled = await Promise.allSettled(jobs.map((job) => job.run()));
    const tracks = [];
    const errors = [];
    const notices = [];
    const bySource = {};

    settled.forEach((outcome, index) => {
      const { source } = jobs[index];
      if (outcome.status === 'rejected') {
        errors.push({ source, message: outcome.reason?.message || 'Unknown provider error' });
        return;
      }
      const { tracks: sourceTracks = [], notice } = outcome.value;
      bySource[source] = sourceTracks.length;
      tracks.push(...sourceTracks);
      if (notice) notices.push({ source, message: notice });
    });

    if (sources.includes('podcasts') && !providerStatus().listennotes && !providerStatus().podcastindex) {
      errors.push({
        source: 'podcasts',
        message: 'No podcast provider configured. Set PODCASTINDEX_API_KEY/SECRET or LISTENNOTES_API_KEY.',
      });
    }
    if (sources.includes('music') && !providerStatus().jamendo && !spotify.isConfigured()) {
      errors.push({ source: 'music', message: 'No music provider configured. Set JAMENDO_CLIENT_ID.' });
    }
    if (sources.includes('youtube') && !providerStatus().youtube) {
      errors.push({ source: 'youtube', message: 'Set YOUTUBE_API_KEY to enable YouTube search.' });
    }

    res.json({
      ...makeResponse({
        source: 'aggregate',
        kind: 'mixed',
        query: q,
        tracks,
        total: tracks.length,
        limit,
        offset: 0,
      }),
      bySource,
      errors,
      notices,
    });
  } catch (error) {
    next(error);
  }
});

/* Per-source endpoints: useful when the UI has separate tabs. */
searchRouter.get('/search/podcasts', async (req, res, next) => {
  try {
    const q = String(req.query.q ?? '').trim();
    const limit = Math.min(Math.max(Number(req.query.limit ?? '20', 10) || 20, 1), 50);
    const offset = Math.max(Number(req.query.offset ?? 0) || 0, 0);
    if (!q) throw new BadRequestError('Provide ?q=');

    if (providerStatus().listennotes) {
      const result = await listennotes.searchEpisodes({ q, limit, offset });
      return res.json(
        makeResponse({ source: 'listennotes', kind: 'podcast', query: q, tracks: result.tracks, total: result.total, limit, offset }),
      );
    }

    const result = await podcastindex.searchEpisodes({ q, limit });
    return res.json(
      makeResponse({
        source: 'podcastindex',
        kind: 'podcast',
        query: q,
        tracks: result.tracks,
        total: result.total,
        limit,
        offset,
        notice: 'PodcastIndex mode: newest episodes of the best matching podcasts.',
      }),
    );
  } catch (error) {
    next(error);
  }
});

searchRouter.get('/search/music', async (req, res, next) => {
  try {
    const q = String(req.query.q ?? '').trim();
    const limit = Math.min(Math.max(Number(req.query.limit ?? '24', 10) || 24, 1), 50);
    const offset = Math.max(Number(req.query.offset ?? 0) || 0, 0);
    const tags = String(req.query.tags ?? '')
      .split(',')
      .map((tag) => tag.trim())
      .filter(Boolean);

    if (!q && !tags.length) throw new BadRequestError('Provide ?q= or ?tags=chill');

    const result = await jamendo.search({ q, limit, offset, tags });
    return res.json(
      makeResponse({ source: 'jamendo', kind: 'music', query: q || null, tracks: result.tracks, total: result.total, limit, offset }),
    );
  } catch (error) {
    next(error);
  }
});

searchRouter.get('/search/youtube', async (req, res, next) => {
  try {
    const q = String(req.query.q ?? '').trim();
    const limit = Math.min(Math.max(Number(req.query.limit ?? '20', 10) || 20, 1), 50);
    if (!q) throw new BadRequestError('Provide ?q=');

    const result = await youtube.search({ q, limit });
    return res.json({
      ...makeResponse({ source: 'youtube', kind: 'youtube', query: q, tracks: result.tracks, total: result.total, limit, offset: 0 }),
      nextPageToken: result.nextPageToken,
    });
  } catch (error) {
    next(error);
  }
});
