import { Router } from 'express';
import { config } from '../config.js';
import { cache } from '../cache.js';
import { BadRequestError } from '../http.js';
import { artworkFrom, makeTrack, stripHtml } from '../normalize.js';
import * as rss from '../providers/rss.js';
import * as podcastindex from '../providers/podcastindex.js';
import * as listennotes from '../providers/listennotes.js';

export const podcastsRouter = Router();

/**
 * GET /api/podcasts/search?q=...
 * Podcast-level rows (artwork, author, feedUrl) to build a browse grid.
 */
podcastsRouter.get('/podcasts/search', async (req, res, next) => {
  try {
    const q = String(req.query.q ?? '').trim();
    const limit = Math.min(Math.max(Number(req.query.limit ?? '12', 10) || 12, 1), 50);
    if (!q) throw new BadRequestError('Provide ?q=');

    if (config.listennotes.key) {
      const result = await listennotes.searchPodcasts({ q, limit });
      return res.json({ ok: true, source: 'listennotes', count: result.podcasts.length, podcasts: result.podcasts });
    }
    if (config.podcastindex.key) {
      const result = await podcastindex.searchFeeds({ q, limit });
      return res.json({ ok: true, source: 'podcastindex', count: result.feeds.length, podcasts: result.feeds });
    }
    throw new BadRequestError('No podcast provider configured.');
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/podcasts/:source/:id/episodes?limit=20&offset=0
 * :source is podcastindex | listennotes | rss
 */
podcastsRouter.get('/podcasts/:source/:id/episodes', async (req, res, next) => {
  try {
    const { source } = req.params;
    const id = String(req.params.id);
    const limit = Math.min(Math.max(Number(req.query.limit ?? '20', 10) || 20, 1), 100);
    const offset = Math.max(Number(req.query.offset ?? 0) || 0, 0);

    if (source === 'podcastindex') {
      const result = await podcastindex.getEpisodes({ feedId: id, limit: limit + offset });
      const episodes = result.episodes.slice(offset, offset + limit);
      return res.json({ ok: true, source, podcastId: id, count: episodes.length, total: result.total, episodes });
    }

    if (source === 'listennotes') {
      const result = await listennotes.getPodcastEpisodes({ podcastId: id, limit, offset });
      return res.json({
        ok: true,
        source,
        podcast: result.podcast,
        count: result.episodes.length,
        total: result.total,
        episodes: result.episodes,
      });
    }

    throw new BadRequestError(`Unsupported podcast source "${source}". Use podcastindex, listennotes or rss.`);
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/rss?url=https://feeds.example.com/show.xml&limit=20
 *
 * The "no API key needed" path: the RSS feed itself carries the mp3 in
 * <enclosure url="...">, which is exactly what an HTML5 <audio> needs.
 */
podcastsRouter.get('/rss', async (req, res, next) => {
  try {
    const feedUrl = String(req.query.url ?? '').trim();
    const limit = Math.min(Math.max(Number(req.query.limit ?? '20', 10) || 20, 1), 200);
    if (!feedUrl) throw new BadRequestError('Provide ?url=<feed url>');

    const key = `rss:${feedUrl}:${limit}`;
    const parsed = await cache.wrap(key, config.cacheTtl.rss, () => rss.fetchFeed(feedUrl));

    const artwork = artworkFrom(parsed.feed.artwork);
    const tracks = parsed.episodes
      .filter((episode) => episode.audioUrl)
      .slice(0, limit)
      .map((episode) =>
        makeTrack({
          id: `rss:${Buffer.from(`${feedUrl}#${episode.guid}`).toString('base64url').slice(0, 32)}`,
          source: 'rss',
          kind: 'podcast',
          title: episode.title,
          subtitle: episode.description,
          artist: parsed.feed.author || parsed.feed.title,
          album: parsed.feed.title,
          artwork: episode.artwork ? artworkFrom(episode.artwork) : artwork,
          durationSec: episode.durationSec,
          publishedAt: episode.publishedAt,
          audioUrl: episode.audioUrl,
          downloadUrl: episode.audioUrl,
          explicit: episode.explicit,
          language: parsed.feed.language,
          links: {
            webpage: episode.link || parsed.feed.link || null,
            feed: feedUrl,
            transcript: episode.transcriptUrl || null,
            chapters: episode.chaptersUrl || null,
          },
          meta: {
            guid: episode.guid,
            episodeNumber: episode.episodeNumber,
            season: episode.season,
            audioType: episode.audioType,
            audioBytes: episode.audioBytes,
          },
        }),
      );

    res.json({
      ok: true,
      source: 'rss',
      feed: {
        title: parsed.feed.title,
        author: parsed.feed.author,
        description: stripHtml(parsed.feed.description, 800),
        artwork,
        language: parsed.feed.language,
        categories: parsed.feed.categories,
        feedUrl,
        webpage: parsed.feed.link || null,
      },
      count: tracks.length,
      totalEpisodesInFeed: parsed.episodes.length,
      tracks,
    });
  } catch (error) {
    next(error);
  }
});

/** Website <-> feed discovery: paste any show URL, get its mp3 enclosures. */
podcastsRouter.get('/rss/discover', async (req, res, next) => {
  try {
    const pageUrl = String(req.query.url ?? '').trim();
    if (!/^https?:\/\//i.test(pageUrl)) throw new BadRequestError('Provide ?url=<site or feed url>');

    // If it already looks like a feed, just parse it.
    if (/\.(xml|rss)(\?|$)/i.test(pageUrl) || /\/feed\/?$/i.test(pageUrl)) {
      const parsed = await rss.fetchFeed(pageUrl);
      return res.json({ ok: true, feedUrl: pageUrl, feed: { title: parsed.feed.title }, episodeCount: parsed.episodes.length });
    }

    const response = await fetch(pageUrl, {
      headers: { 'User-Agent': 'PodWave/1.0', Accept: 'text/html,*/*' },
      redirect: 'follow',
    });
    if (!response.ok) throw new BadRequestError(`Page returned HTTP ${response.status}`);
    const html = await response.text();

    const candidates = new Set();
    const linkTag = /<link[^>]+>/gi;
    for (const tag of html.match(linkTag) || []) {
      if (!/rss\+xml|application\/rss|application\/atom/i.test(tag)) continue;
      const href = /href=["']([^"']+)["']/i.exec(tag)?.[1];
      if (href) candidates.add(new URL(href, pageUrl).toString());
    }

    if (!candidates.size) {
      throw new BadRequestError('No RSS feed advertised on that page. Pass the feed URL directly to /api/rss?url=');
    }

    res.json({ ok: true, pageUrl, candidates: [...candidates] });
  } catch (error) {
    next(error);
  }
});
