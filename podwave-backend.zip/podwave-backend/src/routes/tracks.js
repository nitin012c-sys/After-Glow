import { Router } from 'express';
import { config, providerStatus } from '../config.js';
import { cache } from '../cache.js';
import { BadRequestError } from '../http.js';
import * as jamendo from '../providers/jamendo.js';
import * as spotify from '../providers/spotify.js';
import * as podcastindex from '../providers/podcastindex.js';
import * as listennotes from '../providers/listennotes.js';
import * as youtube from '../providers/youtube.js';

export const tracksRouter = Router();

/*
 * Every lookup is by "qualified id" so the frontend never has to remember
 * which catalog a row came from: jamendo:1234, podcastindex:5678, ...
 * The unqualified /api/track/:id form lets the backend guess by prefix.
 */
tracksRouter.get('/track/:id', async (req, res, next) => {
  try {
    const raw = String(req.params.id);
    const [maybeSource, ...rest] = raw.split(':');
    const hasPrefix = rest.length > 0 && ['jamendo', 'podcastindex', 'listennotes', 'youtube', 'spotify'].includes(maybeSource);

    const source = hasPrefix ? maybeSource : 'jamendo';
    const id = hasPrefix ? rest.join(':') : raw;

    const track = await resolve(source, id);
    res.json({ ok: true, source, track });
  } catch (error) {
    next(error);
  }
});

async function resolve(source, id) {
  switch (source) {
    case 'jamendo':
      return jamendo.getTrack(id);
    case 'podcastindex':
      return podcastindex.getEpisode(id);
    case 'listennotes':
      return listennotes.getEpisode(id);
    case 'youtube':
      return youtube.getVideo(id);
    case 'spotify':
      if (!spotify.isConfigured()) throw new BadRequestError('Spotify is not configured.');
      return spotify.getTrack(id);
    default:
      throw new BadRequestError(`Unknown source "${source}"`);
  }
}

/** Typed aliases, nicer for a client SDK. */
for (const [source, handler] of Object.entries({
  jamendo: (id) => jamendo.getTrack(id),
  podcastindex: (id) => podcastindex.getEpisode(id),
  listennotes: (id) => listennotes.getEpisode(id),
  youtube: (id) => youtube.getVideo(id),
  spotify: async (id) => {
    if (!spotify.isConfigured()) throw new BadRequestError('Spotify is not configured.');
    return spotify.getTrack(id);
  },
})) {
  tracksRouter.get(`/tracks/${source}/:id`, async (req, res, next) => {
    try {
      const track = await handler(String(req.params.id));
      res.json({ ok: true, source, track });
    } catch (error) {
      next(error);
    }
  });
}

/**
 * GET /api/resolve?url=<youtube-or-feed-or-enclosure-url>
 * Paste-a-link endpoint for the player's URL field.
 */
tracksRouter.get('/resolve', async (req, res, next) => {
  try {
    const url = String(req.query.url ?? '').trim();
    if (!url) throw new BadRequestError('Provide ?url=');

    const youtubeId = youtube.extractVideoId(url);
    if (youtubeId) {
      if (!providerStatus().youtube) throw new BadRequestError('Set YOUTUBE_API_KEY to resolve YouTube links.');
      const track = await youtube.getVideo(youtubeId);
      return res.json({ ok: true, source: 'youtube', track });
    }

    if (!/^https?:\/\//i.test(url)) throw new BadRequestError('Only http(s) URLs are supported.');

    // Treat it as a direct audio enclosure: pass-through, no provider needed.
    return res.json({
      ok: true,
      source: 'direct',
      track: {
        id: `direct:${Buffer.from(url).toString('base64url').slice(0, 24)}`,
        source: 'direct',
        kind: 'music',
        title: decodeURIComponent(url.split('/').pop()?.split('?')[0] || 'Remote audio'),
        audioUrl: url,
        proxyUrl: `/api/stream?url=${encodeURIComponent(url)}`,
        playable: true,
        isPreview: false,
      },
    });
  } catch (error) {
    next(error);
  }
});

/** GET /api/providers - which catalogs are live right now. */
tracksRouter.get('/providers', (req, res) => {
  res.json({
    ok: true,
    providers: providerStatus(),
    streamProxy: config.proxy.enabled,
    cache: cache.stats(),
  });
});
