import { Readable } from 'node:stream';
import { Router } from 'express';
import { config } from '../config.js';
import { BadRequestError } from '../http.js';

export const streamRouter = Router();

/**
 * GET /api/stream?url=<encoded audio url>
 *
 * Why this exists: a browser <audio> element needs (a) CORS headers if you draw
 * a waveform / read metadata, and (b) HTTP Range support for seeking. Many
 * podcast hosts are http-only (mixed content on an https site) and some block
 * cross-origin requests. Proxying keeps the frontend simple.
 *
 * SSRF guard: only http/https, and every resolved IP is checked against
 * private/loopback/link-local/metadata ranges. A host allowlist can be set
 * through STREAM_ALLOWED_HOSTS.
 */

const BLOCKED_V4 = [
  [/^10\./, 'private'],
  [/^127\./, 'loopback'],
  [/^169\.254\./, 'link-local'],
  [/^172\.(1[6-9]|2\d|3[01])\./, 'private'],
  [/^192\.168\./, 'private'],
  [/^0\./, 'reserved'],
  [/^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./, 'carrier-grade NAT'],
];

function assertHostAllowed(hostname) {
  const host = hostname.toLowerCase();
  if (config.proxy.allowedHosts.length && !config.proxy.allowedHosts.includes(host)) {
    throw new BadRequestError(`Host ${host} is not in STREAM_ALLOWED_HOSTS`);
  }
  if (host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.internal') || host.endsWith('.local')) {
    throw new BadRequestError('Refusing to proxy internal hosts');
  }
  // Literal IPv4
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) {
    if (BLOCKED_V4.some(([pattern]) => pattern.test(host))) {
      throw new BadRequestError('Refusing to proxy a private IP address');
    }
  }
  // Literal IPv6
  if (host.includes(':')) {
    if (host === '::1' || host.startsWith('fe80') || host.startsWith('fc') || host.startsWith('fd')) {
      throw new BadRequestError('Refusing to proxy a private IPv6 address');
    }
  }
}

streamRouter.get('/stream', async (req, res, next) => {
  try {
    if (!config.proxy.enabled) throw new BadRequestError('Stream proxy is disabled (STREAM_PROXY_ENABLED=false).');

    const target = String(req.query.url ?? '').trim();
    if (!target) throw new BadRequestError('Provide ?url=<encoded audio url>');

    let parsed;
    try {
      parsed = new URL(target);
    } catch {
      throw new BadRequestError('url is not a valid absolute URL');
    }
    if (!/^https?:$/.test(parsed.protocol)) throw new BadRequestError('Only http and https URLs can be proxied');
    assertHostAllowed(parsed.hostname);

    const range = req.headers.range;
    const controller = new AbortController();
    // Abort upstream if the browser navigates away mid-stream.
    req.on('close', () => controller.abort());

    const upstream = await fetch(parsed.toString(), {
      headers: {
        // Forward Range so seeking works, and a UA because some hosts 403 on none.
        ...(range ? { Range: range } : {}),
        'User-Agent': 'PodWave/1.0 (+audio proxy)',
        Accept: 'audio/*,application/octet-stream,*/*',
      },
      redirect: 'follow',
      signal: controller.signal,
    });

    if (!upstream.ok && upstream.status !== 206) {
      throw new BadRequestError(`Upstream returned HTTP ${upstream.status}`);
    }

    const contentType = upstream.headers.get('content-type') || 'audio/mpeg';
    const contentLength = Number(upstream.headers.get('content-length') || 0);

    if (config.proxy.maxBytes && contentLength > config.proxy.maxBytes) {
      throw new BadRequestError('File exceeds STREAM_PROXY_MAX_BYTES');
    }

    res.status(upstream.status === 206 ? 206 : 200);
    res.setHeader('Content-Type', contentType);
    res.setHeader('Accept-Ranges', upstream.headers.get('accept-ranges') || 'bytes');
    // Everything here is third-party media: let the CDN/browser cache it.
    res.setHeader('Cache-Control', 'public, max-age=3600');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Expose-Headers', 'Content-Length, Content-Range, Accept-Ranges');

    if (upstream.headers.get('content-range')) res.setHeader('Content-Range', upstream.headers.get('content-range'));
    if (upstream.headers.get('content-length')) res.setHeader('Content-Length', upstream.headers.get('content-length'));
    if (upstream.headers.get('etag')) res.setHeader('ETag', upstream.headers.get('etag'));

    if (req.method === 'HEAD' || !upstream.body) {
      return res.end();
    }

    const nodeStream = Readable.fromWeb(upstream.body);
    nodeStream.on('error', () => res.destroy());
    nodeStream.pipe(res);
  } catch (error) {
    if (res.headersSent) return res.destroy();
    next(error);
  }
});
