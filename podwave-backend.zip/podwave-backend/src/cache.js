/**
 * Tiny in-process TTL cache with in-flight request de-duplication.
 *
 * Why no Redis: search responses are cheap to rebuild and this keeps the
 * project zero-infrastructure. `cache.wrap()` also collapses concurrent
 * identical requests into one upstream call, which is the main thing that
 * protects you against burning an API quota when a page renders 20 requests.
 *
 * Swap the `store` for ioredis when you run more than one instance.
 */
export class TtlCache {
  constructor({ maxEntries = 800 } = {}) {
    this.maxEntries = maxEntries;
    this.store = new Map();
    this.hits = 0;
    this.misses = 0;
  }

  get(key) {
    const entry = this.store.get(key);
    if (!entry) {
      this.misses += 1;
      return undefined;
    }
    if (entry.expires <= Date.now()) {
      this.store.delete(key);
      this.misses += 1;
      return undefined;
    }
    this.hits += 1;
    return entry.value;
  }

  set(key, value, ttlSeconds) {
    if (!ttlSeconds || ttlSeconds <= 0) return value;
    // Re-insert so insertion order keeps acting as "oldest first".
    this.store.delete(key);
    this.store.set(key, { value, expires: Date.now() + ttlSeconds * 1000 });
    while (this.store.size > this.maxEntries) {
      const oldest = this.store.keys().next().value;
      this.store.delete(oldest);
    }
    return value;
  }

  /** get-or-compute. Returns a Promise; concurrent callers share one run. */
  wrap(key, ttlSeconds, producer) {
    const cached = this.get(key);
    if (cached !== undefined) return cached;

    const pending = (async () => producer())();
    this.set(key, pending, ttlSeconds);
    // Never cache a rejection.
    pending.catch(() => this.store.delete(key));
    return pending;
  }

  stats() {
    const total = this.hits + this.misses;
    return {
      entries: this.store.size,
      hits: this.hits,
      misses: this.misses,
      hitRate: total ? Number((this.hits / total).toFixed(3)) : 0,
    };
  }

  clear() {
    this.store.clear();
  }
}

export const cache = new TtlCache();
