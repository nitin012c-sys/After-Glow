import { setTimeout as sleep } from 'node:timers/promises';

/** An error raised by an upstream API, safe to surface to the client. */
export class UpstreamError extends Error {
  constructor(message, { provider = 'upstream', status = 0, body = '' } = {}) {
    super(message);
    this.name = 'UpstreamError';
    this.provider = provider;
    this.status = status;
    this.body = body;
    this.expose = true;
  }
}

export class BadRequestError extends Error {
  constructor(message) {
    super(message);
    this.name = 'BadRequestError';
    this.status = 400;
    this.expose = true;
  }
}

/**
 * JSON GET with timeout + retry on 429/5xx and on network failure.
 * Returns the parsed body. Throws UpstreamError on anything non-2xx.
 */
export async function fetchJson(url, { provider = 'upstream', headers = {}, timeoutMs = 12_000, retries = 2 } = {}) {
  let lastError;

  for (let attempt = 0; attempt <= retries; attempt += 1) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const response = await fetch(url, {
        headers: { Accept: 'application/json', ...headers },
        signal: controller.signal,
        redirect: 'follow',
      });

      const text = await response.text();

      if (!response.ok) {
        const error = new UpstreamError(`${provider} responded with HTTP ${response.status}`, {
          provider,
          status: response.status,
          body: text.slice(0, 400),
        });
        // 429 and 5xx are worth retrying; 4xx are configuration problems.
        if ((response.status === 429 || response.status >= 500) && attempt < retries) {
          lastError = error;
          await sleep(350 * (attempt + 1));
          continue;
        }
        throw error;
      }

      try {
        return JSON.parse(text);
      } catch {
        throw new UpstreamError(`${provider} returned a non-JSON body`, {
          provider,
          status: response.status,
          body: text.slice(0, 200),
        });
      }
    } catch (error) {
      if (error instanceof UpstreamError) throw error;

      const message = error?.name === 'AbortError' ? `timed out after ${timeoutMs}ms` : error.message;
      lastError = new UpstreamError(`${provider} request failed: ${message}`, { provider, status: 0 });
      if (attempt < retries) {
        await sleep(350 * (attempt + 1));
        continue;
      }
      throw lastError;
    } finally {
      clearTimeout(timer);
    }
  }

  throw lastError;
}

/** Build a query string, dropping undefined/null/empty values. */
export function qs(params) {
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value === undefined || value === null || value === '') continue;
    if (Array.isArray(value)) {
      if (!value.length) continue;
      search.set(key, value.join(','));
    } else {
      search.set(key, String(value));
    }
  }
  return search.toString();
}

export const clamp = (value, min, max) => Math.min(Math.max(value, min), max);
