import 'dotenv/config';

const num = (value, fallback) => {
  const parsed = Number.parseInt(value ?? '', 10);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const bool = (value, fallback = false) => {
  if (value === undefined || value === '') return fallback;
  return /^(1|true|yes|on)$/i.test(String(value));
};

const list = (value) =>
  String(value ?? '')
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean);

export const config = {
  port: num(process.env.PORT, 8080),
  nodeEnv: process.env.NODE_ENV || 'development',
  corsOrigins: list(process.env.CORS_ORIGINS).length ? list(process.env.CORS_ORIGINS) : ['*'],

  cacheTtl: {
    search: num(process.env.CACHE_TTL_SEARCH, 300),
    track: num(process.env.CACHE_TTL_TRACK, 600),
    episodes: num(process.env.CACHE_TTL_EPISODES, 600),
    rss: num(process.env.CACHE_TTL_RSS, 900),
  },

  rateLimit: {
    windowMs: num(process.env.RATE_LIMIT_WINDOW_MS, 60_000),
    max: num(process.env.RATE_LIMIT_MAX, 60),
  },

  podcastindex: {
    baseUrl: (process.env.PODCASTINDEX_BASE_URL || 'https://api.podcastindex.org/api/1.0').replace(/\/+$/, ''),
    key: process.env.PODCASTINDEX_API_KEY || '',
    secret: process.env.PODCASTINDEX_API_SECRET || '',
    userAgent: process.env.PODCASTINDEX_USER_AGENT || 'PodWave/1.0',
  },

  listennotes: {
    baseUrl: 'https://listen-api.listennotes.com/api/v2',
    key: process.env.LISTENNOTES_API_KEY || '',
  },

  jamendo: {
    baseUrl: 'https://api.jamendo.com/v3.0',
    clientId: process.env.JAMENDO_CLIENT_ID || '',
  },

  youtube: {
    baseUrl: 'https://www.googleapis.com/youtube/v3',
    key: process.env.YOUTUBE_API_KEY || '',
    embedBase: 'https://www.youtube.com/embed/',
    watchBase: 'https://www.youtube.com/watch?v=',
  },

  proxy: {
    enabled: bool(process.env.STREAM_PROXY_ENABLED, true),
    maxBytes: num(process.env.STREAM_PROXY_MAX_BYTES, 0),
    allowedHosts: list(process.env.STREAM_ALLOWED_HOSTS).map((host) => host.toLowerCase()),
  },
};

/** Provider availability, used for /api/providers and for graceful degradation. */
export const providers = {
  podcastindex: () => Boolean(config.podcastindex.key && config.podcastindex.secret),
  listennotes: () => Boolean(config.listennotes.key),
  jamendo: () => Boolean(config.jamendo.clientId),
  youtube: () => Boolean(config.youtube.key),
  rss: () => true, // works with no credentials
};

export const providerStatus = () =>
  Object.fromEntries(Object.entries(providers).map(([name, check]) => [name, check()]));
