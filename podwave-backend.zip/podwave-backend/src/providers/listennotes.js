import { config } from '../config.js';
import { cache } from '../cache.js';
import { fetchJson, qs, clamp, BadRequestError } from '../http.js';
import { artworkFrom, makeTrack, parseDuration, stripHtml } from '../normalize.js';

/**
 * Listen Notes API v2  -  https://www.listennotes.com/api/docs/
 *
 * Auth (documented): header `X-ListenAPI-Key: <your key>`
 * Base URL: https://listen-api.listennotes.com/api/v2
 *
 * Endpoints used:
 *   GET /search?q=            -> podcasts (type=podcast|episode|curated)
 *   GET /search_episode?q=    -> episodes with a direct `audio` url
 *   GET /podcasts/{id}        -> podcast + its episodes
 *   GET /episodes/{id}        -> single episode
 *
 * Result fields confirmed against the OpenAPI spec: audio, audio_length_sec,
 * image, thumbnail, pub_date_ms, title_original, listennotes_url.
 */

const requireKey = () => {
  if (!config.listennotes.key) {
    throw new BadRequestError(
      'ListenNotes is not configured. Set LISTENNOTES_API_KEY in .env (free tier at https://www.listennotes.com/api/pricing/).',
    );
  }
};

async function get(path, params = {}) {
  requireKey();
  const query = qs(params);
  const url = `${config.listennotes.baseUrl}${path}${query ? `?${query}` : ''}`;
  return fetchJson(url, { provider: 'listennotes', headers: { 'X-ListenAPI-Key': config.listennotes.key } });
}

function mapEpisode(raw, podcast = {}) {
  const artwork = artworkFrom(raw.image, raw.thumbnail, podcast.image, podcast.thumbnail);
  const audioUrl = raw.audio || null;

  return makeTrack({
    id: `listennotes:${raw.id}`,
    source: 'listennotes',
    kind: 'podcast',
    title: stripHtml(raw.title_original || raw.title, 300),
    subtitle: stripHtml(raw.description_original || raw.description, 400),
    artist: stripHtml(podcast.title_original || raw.podcast_title_original || '', 200),
    album: stripHtml(podcast.title_original || '', 200),
    artwork,
    durationSec: Number(raw.audio_length_sec) || parseDuration(raw.audio_length_sec),
    // pub_date_ms is an epoch timestamp in MILLISECONDS per the spec.
    publishedAt: raw.pub_date_ms ? new Date(Number(raw.pub_date_ms)).toISOString() : null,
    audioUrl,
    downloadUrl: audioUrl,
    explicit: Boolean(raw.explicit_content),
    language: raw.language || podcast.language || null,
    links: {
      self: `/api/tracks/listennotes/${raw.id}`,
      webpage: raw.listennotes_url || null,
      podcast: podcast.id ? `/api/podcasts/listennotes/${podcast.id}/episodes` : null,
    },
    meta: {
      listennotesEpisodeId: raw.id,
      podcastId: podcast.id || raw.podcast_id || null,
      publisher: podcast.publisher_original || null,
      audioLengthSec: raw.audio_length_sec ?? null,
      maybeAudioInvalid: raw.maybe_audio_invalid ?? null,
      thumbnail: raw.thumbnail || null,
    },
  });
}

export async function searchEpisodes({ q, limit = 20, offset = 0, sortByDate = false }) {
  const safeLimit = clamp(Number(limit) || 20, 1, 50);
  const safeOffset = Math.max(0, Number(offset) || 0);
  const key = `ln:episodes:${q}:${safeLimit}:${safeOffset}:${sortByDate}`;

  return cache.wrap(key, config.cacheTtl.search, async () => {
    const body = await get('/search_episode', {
      q,
      offset: safeOffset,
      lenient: 'true',
      sort_by_date: sortByDate ? 1 : 0,
      only_in: 'title,description',
    });
    const results = Array.isArray(body?.results) ? body.results : [];
    return {
      tracks: results.map((item) => mapEpisode(item, item.podcast || {})),
      total: body?.total ?? results.length,
      nextOffset: body?.next_offset ?? null,
    };
  });
}

export async function searchPodcasts({ q, limit = 12 }) {
  const key = `ln:podcasts:${q}:${limit}`;
  return cache.wrap(key, config.cacheTtl.search, async () => {
    const body = await get('/search', { q, type: 'podcast', lenient: 'true' });
    const results = Array.isArray(body?.results) ? body.results : [];
    return {
      podcasts: results.slice(0, clamp(Number(limit) || 12, 1, 50)).map((raw) => ({
        id: `listennotes:${raw.id}`,
        source: 'listennotes',
        title: stripHtml(raw.title_original, 300),
        author: stripHtml(raw.publisher_original, 200),
        description: stripHtml(raw.description_original, 600),
        artwork: artworkFrom(raw.image, raw.thumbnail),
        episodeCount: raw.total_episodes ?? null,
        language: raw.language || null,
        links: {
          webpage: raw.listennotes_url || null,
          episodes: `/api/podcasts/listennotes/${raw.id}/episodes`,
        },
      })),
      total: body?.total ?? results.length,
    };
  });
}

export async function getPodcastEpisodes({ podcastId, limit = 20, offset = 0 }) {
  const key = `ln:podcast:${podcastId}:${limit}:${offset}`;
  return cache.wrap(key, config.cacheTtl.episodes, async () => {
    const body = await get(`/podcasts/${encodeURIComponent(podcastId)}`, { sort: 'recent_first' });
    const episodes = Array.isArray(body?.episodes) ? body.episodes : [];
    const podcast = { id: body?.id, title_original: body?.title, image: body?.image, publisher_original: body?.publisher };
    return {
      episodes: episodes.slice(offset, offset + limit).map((item) => mapEpisode(item, podcast)),
      total: episodes.length,
      podcast: body
        ? {
            id: `listennotes:${body.id}`,
            title: stripHtml(body.title, 300),
            author: stripHtml(body.publisher, 200),
            artwork: artworkFrom(body.image, body.thumbnail),
            feedUrl: body.rss || null,
          }
        : null,
    };
  });
}

export async function getEpisode(episodeId) {
  const key = `ln:episode:${episodeId}`;
  return cache.wrap(key, config.cacheTtl.track, async () => {
    const body = await get(`/episodes/${encodeURIComponent(episodeId)}`);
    if (!body?.id) throw new BadRequestError(`ListenNotes episode ${episodeId} not found`);
    return mapEpisode(body, {
      id: body.podcast?.id,
      title_original: body.podcast?.title,
      image: body.podcast?.image,
    });
  });
}
