import crypto from 'node:crypto';
import { config } from '../config.js';
import { cache } from '../cache.js';
import { fetchJson, qs, clamp, BadRequestError } from '../http.js';
import { artworkFrom, makeTrack, stripHtml } from '../normalize.js';

/**
 * PodcastIndex API 1.0  -  https://podcastindex-org.github.io/docs-api/
 *
 * Auth (documented): three headers
 *   X-Auth-Key      : your API key
 *   X-Auth-Date     : current unix timestamp in SECONDS
 *   Authorization   : sha1(apiKey + apiSecret + unixTimestamp) as hex
 * Docs note the date must be within a few minutes of server time.
 *
 * Endpoints used (all confirmed in the docs):
 *   GET /search/byterm?q=...            -> { feeds: [...] }
 *   GET /podcasts/byfeedid?id=...       -> { feed: {...} }
 *   GET /episodes/byfeedid?id=...       -> { items: [...] }   (enclosureUrl = mp3)
 *   GET /episodes/byid?id=...           -> { episode: {...} }
 */

const requireAuth = () => {
  if (!config.podcastindex.key || !config.podcastindex.secret) {
    throw new BadRequestError(
      'PodcastIndex is not configured. Set PODCASTINDEX_API_KEY and PODCASTINDEX_API_SECRET in .env (free at https://api.podcastindex.org/signup).',
    );
  }
};

export function authHeaders() {
  const apiKey = config.podcastindex.key;
  const apiSecret = config.podcastindex.secret;
  const unixTime = Math.floor(Date.now() / 1000);
  const authorization = crypto.createHash('sha1').update(`${apiKey}${apiSecret}${unixTime}`).digest('hex');

  return {
    'X-Auth-Key': apiKey,
    'X-Auth-Date': String(unixTime),
    Authorization: authorization,
    'User-Agent': config.podcastindex.userAgent,
  };
}

async function get(path, params) {
  requireAuth();
  const query = qs(params);
  const url = `${config.podcastindex.baseUrl}${path}?${query}`;
  // Headers are regenerated per call so the timestamp never goes stale.
  return fetchJson(url, { provider: 'podcastindex', headers: authHeaders() });
}

function mapEpisode(raw, feed) {
  const artwork = artworkFrom(raw.image || raw.feedImage, feed?.image, feed?.artwork);
  const audioUrl = raw.enclosureUrl || null;

  return makeTrack({
    id: `podcastindex:${raw.id}`,
    source: 'podcastindex',
    kind: 'podcast',
    title: stripHtml(raw.title, 300),
    subtitle: stripHtml(raw.description, 400),
    artist: stripHtml(feed?.title || raw.feedTitle || '', 200),
    album: stripHtml(feed?.title || '', 200),
    artwork,
    durationSec: Number(raw.duration) || 0,
    publishedAt: raw.datePublished ? new Date(raw.datePublished * 1000).toISOString() : null,
    audioUrl,
    downloadUrl: audioUrl,
    links: {
      self: `/api/tracks/podcastindex/${raw.id}`,
      webpage: raw.link || null,
      podcast: feed?.feedId ? `/api/podcasts/podcastindex/${feed.feedId}/episodes` : null,
      transcript: raw.transcriptUrl || null,
    },
    explicit: Boolean(raw.explicit),
    meta: {
      podcastIndexEpisodeId: raw.id,
      feedId: raw.feedId || feed?.feedId || null,
      episode: raw.episode ?? null,
      season: raw.season ?? null,
      episodeType: raw.episodeType || null,
      audioType: raw.enclosureType || null,
      audioBytes: raw.enclosureLength || 0,
      chaptersUrl: raw.chaptersUrl || null,
      soundbite: raw.soundbite || null,
    },
  });
}

function mapFeed(raw) {
  return {
    id: `podcastindex:${raw.id}`,
    source: 'podcastindex',
    title: stripHtml(raw.title, 300),
    author: stripHtml(raw.author || raw.ownerName || '', 200),
    description: stripHtml(raw.description, 600),
    artwork: artworkFrom(raw.image, raw.artwork),
    feedUrl: raw.url || null,
    episodeCount: raw.episodeCount ?? null,
    categories: Object.values(raw.categories || {}),
    language: raw.language || null,
    explicit: Boolean(raw.explicit),
    links: {
      webpage: raw.link || null,
      episodes: `/api/podcasts/podcastindex/${raw.id}/episodes`,
    },
  };
}

export async function searchFeeds({ q, limit = 12 }) {
  const safeLimit = clamp(Number(limit) || 12, 1, 100);
  const key = `pi:feeds:${q}:${safeLimit}`;

  return cache.wrap(key, config.cacheTtl.search, async () => {
    const body = await get('/search/byterm', { q, max: safeLimit, fulltext: 'true' });
    const feeds = Array.isArray(body?.feeds) ? body.feeds : [];
    return { feeds: feeds.map(mapFeed), total: body?.count ?? feeds.length };
  });
}

export async function getFeed(feedId) {
  const key = `pi:feed:${feedId}`;
  return cache.wrap(key, config.cacheTtl.episodes, async () => {
    const body = await get('/podcasts/byfeedid', { id: feedId });
    const raw = body?.feed;
    if (!raw) throw new BadRequestError(`PodcastIndex feed ${feedId} not found`);
    return mapFeed(raw);
  });
}

export async function getEpisodes({ feedId, limit = 20, since = null }) {
  const safeLimit = clamp(Number(limit) || 20, 1, 1000);
  const key = `pi:episodes:${feedId}:${safeLimit}:${since || ''}`;

  return cache.wrap(key, config.cacheTtl.episodes, async () => {
    const body = await get('/episodes/byfeedid', {
      id: feedId,
      max: safeLimit,
      since: since || undefined,
    });
    const items = Array.isArray(body?.items) ? body.items : [];
    const feed = {
      feedId: Number(feedId),
      title: items[0]?.feedTitle || '',
      image: items[0]?.feedImage || '',
    };
    return { episodes: items.map((item) => mapEpisode(item, feed)), total: body?.count ?? items.length };
  });
}

export async function getEpisode(episodeId) {
  const key = `pi:episode:${episodeId}`;
  return cache.wrap(key, config.cacheTtl.track, async () => {
    const body = await get('/episodes/byid', { id: episodeId });
    const raw = body?.episode;
    if (!raw) throw new BadRequestError(`PodcastIndex episode ${episodeId} not found`);
    return mapEpisode(raw, { feedId: raw.feedId, title: raw.feedTitle, image: raw.feedImage });
  });
}

/**
 * Playable episode search without ListenNotes.
 *
 * PodcastIndex /search/byterm returns PODCASTS, not episodes, so a real
 * "play this now" search needs one hop: find feeds, then pull the newest
 * episode of the best few. Bounded + cached so it stays one cheap burst.
 */
export async function searchEpisodes({ q, limit = 20, feedFanout = 8 }) {
  const safeLimit = clamp(Number(limit) || 20, 1, 50);
  const { feeds } = await searchFeeds({ q, limit: clamp(feedFanout, 1, 20) });

  const hydrated = await Promise.all(
    feeds.map(async (feed) => {
      const feedId = String(feed.id).replace('podcastindex:', '');
      try {
        const { episodes } = await getEpisodes({ feedId, limit: 2 });
        return episodes.map((episode) => ({
          ...episode,
          album: feed.title,
          artist: feed.author || feed.title,
          artwork: episode.artwork.small ? episode.artwork : feed.artwork,
        }));
      } catch {
        return [];
      }
    }),
  );

  const tracks = hydrated.flat().filter((track) => track.audioUrl).slice(0, safeLimit);
  return { tracks, total: tracks.length, feeds };
}
