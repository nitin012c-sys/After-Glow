import { config } from '../config.js';
import { cache } from '../cache.js';
import { fetchJson, qs, clamp, BadRequestError } from '../http.js';
import { artworkFrom, makeTrack, parseDuration, stripHtml } from '../normalize.js';

/**
 * YouTube Data API v3  -  SEARCH + METADATA ONLY.
 * Docs: https://developers.google.com/youtube/v3/docs/search/list
 *   GET https://www.googleapis.com/youtube/v3/search
 *   required: part=snippet   (plus key, q, type, maxResults)
 *
 * This module deliberately returns `audioUrl: null` and playability through the
 * official IFrame embed. Extracting the audio track (yt-dlp, "mp3 converter"
 * endpoints) breaks the YouTube Terms of Service, so it is not implemented
 * here - see README "Why there is no YouTube -> MP3 route".
 *
 * The videoId is parsed defensively because search returns several id shapes.
 */
const requireKey = () => {
  if (!config.youtube.key) {
    throw new BadRequestError(
      'YouTube is not configured. Set YOUTUBE_API_KEY in .env (Get one at https://console.cloud.google.com/apis/credentials).',
    );
  }
};

const ISO_DURATION = /^P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/;

function isoDurationToSeconds(value) {
  const match = ISO_DURATION.exec(String(value || ''));
  if (!match) return 0;
  const [, days, hours, minutes, seconds] = match.map((part) => Number.parseInt(part, 10) || 0);
  return days * 86400 + hours * 3600 + minutes * 60 + seconds;
}

function pickThumbnail(thumbnails = {}) {
  return (
    thumbnails.maxres?.url ||
    thumbnails.standard?.url ||
    thumbnails.high?.url ||
    thumbnails.medium?.url ||
    thumbnails.default?.url ||
    null
  );
}

function mapVideo(item, details = {}) {
  const videoId = item.id?.videoId || item.id || details.id;
  const snippet = item.snippet || {};
  const contentDetails = details.contentDetails || {};
  const statistics = details.statistics || {};

  return makeTrack({
    id: `youtube:${videoId}`,
    source: 'youtube',
    kind: 'youtube',
    title: stripHtml(snippet.title, 300),
    subtitle: stripHtml(snippet.description, 400),
    artist: stripHtml(snippet.channelTitle, 200),
    album: stripHtml(snippet.channelTitle, 200),
    artwork: artworkFrom(pickThumbnail(snippet.thumbnails)),
    durationSec: isoDurationToSeconds(contentDetails.duration) || parseDuration(item.duration),
    publishedAt: snippet.publishedAt ? new Date(snippet.publishedAt).toISOString() : null,
    audioUrl: null, // intentionally none: use the embed
    embedUrl: videoId ? `${config.youtube.embedBase}${videoId}` : null,
    videoUrl: videoId ? `${config.youtube.watchBase}${videoId}` : null,
    language: snippet.defaultAudioLanguage || null,
    links: {
      self: `/api/tracks/youtube/${videoId}`,
      webpage: videoId ? `${config.youtube.watchBase}${videoId}` : null,
      channel: snippet.channelId ? `https://www.youtube.com/channel/${snippet.channelId}` : null,
    },
    meta: {
      videoId,
      channelId: snippet.channelId || null,
      channelTitle: snippet.channelTitle || null,
      liveBroadcastContent: snippet.liveBroadcastContent || 'none',
      definition: contentDetails.definition || null,
      viewCount: statistics.viewCount ? Number(statistics.viewCount) : null,
      likeCount: statistics.likeCount ? Number(statistics.likeCount) : null,
      embedAllowed: true,
      note: 'Playback is via the official YouTube IFrame embed. Audio extraction is not provided.',
    },
  });
}

export async function search({ q, limit = 20, order = 'relevance', videoDuration = 'any' }) {
  requireKey();
  const safeLimit = clamp(Number(limit) || 20, 1, 50);
  const key = `yt:search:${q}:${safeLimit}:${order}:${videoDuration}`;

  return cache.wrap(key, config.cacheTtl.search, async () => {
    const url = `${config.youtube.baseUrl}/search?${qs({
      key: config.youtube.key,
      part: 'snippet',
      q,
      type: 'video',
      maxResults: safeLimit,
      order,
      videoDuration,
      safeSearch: 'moderate',
    })}`;

    const body = await fetchJson(url, { provider: 'youtube' });
    const items = Array.isArray(body?.items) ? body.items.filter((item) => item.id?.videoId) : [];
    if (!items.length) {
      return { tracks: [], total: body?.pageInfo?.totalResults ?? 0, nextPageToken: null };
    }

    // One extra videos.list call fills in ISO-8601 durations + statistics.
    let detailsById = new Map();
    try {
      const detailUrl = `${config.youtube.baseUrl}/videos?${qs({
        key: config.youtube.key,
        part: 'contentDetails,statistics,status',
        id: items.map((item) => item.id.videoId),
      })}`;
      const details = await fetchJson(detailUrl, { provider: 'youtube' });
      detailsById = new Map((details?.items || []).map((entry) => [entry.id, entry]));
    } catch {
      // Durations are a nice-to-have; a failed hydration must not kill search.
    }

    return {
      tracks: items.map((item) => mapVideo(item, detailsById.get(item.id.videoId))),
      total: body?.pageInfo?.totalResults ?? items.length,
      nextPageToken: body?.nextPageToken ?? null,
    };
  });
}

export async function getVideo(videoId) {
  requireKey();
  const key = `yt:video:${videoId}`;
  return cache.wrap(key, config.cacheTtl.track, async () => {
    const url = `${config.youtube.baseUrl}/videos?${qs({
      key: config.youtube.key,
      part: 'snippet,contentDetails,statistics',
      id: videoId,
    })}`;
    const body = await fetchJson(url, { provider: 'youtube' });
    const item = body?.items?.[0];
    if (!item) throw new BadRequestError(`YouTube video ${videoId} not found`);
    return mapVideo({ id: videoId, snippet: item.snippet }, item);
  });
}

/** Accepts a raw id, youtu.be link, watch?v= link, or /shorts/ link. */
export function extractVideoId(input) {
  const value = String(input || '').trim();
  if (!value) return null;
  if (/^[A-Za-z0-9_-]{11}$/.test(value)) return value;
  const patterns = [
    /[?&]v=([A-Za-z0-9_-]{11})/,
    /youtu\.be\/([A-Za-z0-9_-]{11})/,
    /\/embed\/([A-Za-z0-9_-]{11})/,
    /\/shorts\/([A-Za-z0-9_-]{11})/,
    /\/live\/([A-Za-z0-9_-]{11})/,
  ];
  for (const pattern of patterns) {
    const match = pattern.exec(value);
    if (match) return match[1];
  }
  return null;
}
