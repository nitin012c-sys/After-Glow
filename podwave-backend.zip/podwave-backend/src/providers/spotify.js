import { config } from '../config.js';
import { cache } from '../cache.js';
import { fetchJson, qs, clamp } from '../http.js';
import { artworkFrom, makeTrack } from '../normalize.js';

/**
 * Spotify Web API  -  METADATA + 30-SECOND PREVIEWS ONLY.
 *
 * Auth: Client Credentials flow (server-to-server, no user login needed).
 *   POST https://accounts.spotify.com/api/token
 *   Authorization: Basic base64(client_id:client_secret)
 *   Content-Type: application/x-www-form-urlencoded
 *   body: grant_type=client_credentials
 *
 * Per Spotify's docs a preview_url is a short clip, so every track from here is
 * flagged isPreview: true. Full playback requires the user's Premium account
 * plus the Web Playback SDK on the frontend - out of scope for a backend.
 *
 * This module is optional: it only activates when SPOTIFY_CLIENT_ID and
 * SPOTIFY_CLIENT_SECRET are set.
 */

let token = { value: null, expiresAt: 0 };

const credentials = () => ({
  clientId: process.env.SPOTIFY_CLIENT_ID || '',
  clientSecret: process.env.SPOTIFY_CLIENT_SECRET || '',
});

export const isConfigured = () => {
  const { clientId, clientSecret } = credentials();
  return Boolean(clientId && clientSecret);
};

async function getToken() {
  if (!isConfigured()) return null;
  if (token.value && token.expiresAt > Date.now() + 30_000) return token.value;

  const { clientId, clientSecret } = credentials();
  const basic = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');

  const response = await fetch('https://accounts.spotify.com/api/token', {
    method: 'POST',
    headers: {
      Authorization: `Basic ${basic}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({ grant_type: 'client_credentials' }),
  });

  if (!response.ok) {
    const detail = await response.text();
    throw new Error(`Spotify token request failed (${response.status}): ${detail.slice(0, 200)}`);
  }

  const body = await response.json();
  token = {
    value: body.access_token,
    expiresAt: Date.now() + (Number(body.expires_in) || 3600) * 1000,
  };
  return token.value;
}

function mapTrack(raw) {
  const artists = (raw.artists || []).map((artist) => artist.name).filter(Boolean);
  const images = raw.album?.images || [];
  const artwork = artworkFrom(images[0]?.url, images[1]?.url);

  return makeTrack({
    id: `spotify:${raw.id}`,
    source: 'spotify',
    kind: 'music',
    title: raw.name,
    subtitle: artists.join(', '),
    artist: artists.join(', '),
    album: raw.album?.name || '',
    artwork,
    durationSec: Math.round((Number(raw.duration_ms) || 0) / 1000),
    publishedAt: raw.album?.release_date ? new Date(`${raw.album.release_date}T00:00:00Z`).toISOString() : null,
    audioUrl: raw.preview_url || null,
    isPreview: true, // Spotify preview clips only (~30s)
    explicit: Boolean(raw.explicit),
    links: {
      self: `/api/tracks/spotify/${raw.id}`,
      webpage: raw.external_urls?.spotify || null,
    },
    meta: {
      spotifyId: raw.id,
      popularity: raw.popularity ?? null,
      previewAvailable: Boolean(raw.preview_url),
      note: 'Spotify preview clips are ~30s. Full tracks require the Web Playback SDK with a Premium login.',
    },
  });
}

export async function search({ q, limit = 20 }) {
  const accessToken = await getToken();
  if (!accessToken) return { tracks: [], total: 0, notice: 'Spotify is not configured.' };

  const safeLimit = clamp(Number(limit) || 20, 1, 50);
  const key = `spotify:search:${q}:${safeLimit}`;

  return cache.wrap(key, config.cacheTtl.search, async () => {
    const body = await fetchJson(
      `https://api.spotify.com/v1/search?${qs({ q, type: 'track', limit: safeLimit, market: 'US' })}`,
      { provider: 'spotify', headers: { Authorization: `Bearer ${accessToken}` } },
    );
    const items = body?.tracks?.items || [];
    return {
      tracks: items.map(mapTrack),
      total: body?.tracks?.total ?? items.length,
      notice: 'Spotify results are 30-second previews (isPreview: true).',
    };
  });
}

