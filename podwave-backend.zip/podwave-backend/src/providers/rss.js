import { XMLParser } from 'fast-xml-parser';
import { UpstreamError } from '../http.js';
import { parseDuration, toIso, stripHtml } from '../normalize.js';

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: '@_',
  textNodeName: '#text',
  trimValues: true,
  parseTagValue: false, // keep "2024" from becoming a number
  // Feeds use named HTML entities heavily; the parser's entity expansion
  // cap trips on large real-world feeds, so entities are decoded in
  // stripHtml() / decodeEntities() instead of by the parser.
  processEntities: false,
  htmlEntities: false,
  isArray: (name) =>
    ['item', 'enclosure', 'itunes:category', 'itunes:image', 'link', 'content:encoded', 'podcast:person', 'podcast:transcript'].includes(name),
});

const asArray = (value) => {
  if (value === undefined || value === null) return [];
  return Array.isArray(value) ? value : [value];
};

/** fast-xml-parser returns {"#text": "...", "@_href": "..."} for attributed tags. */
const ENTITIES = {
  '&amp;': '&', '&lt;': '<', '&gt;': '>', '&quot;': '"', '&apos;': "'", '&#39;': "'",
  '&nbsp;': ' ', '&ndash;': '–', '&mdash;': '—', '&hellip;': '…', '&rsquo;': '’',
  '&lsquo;': '‘', '&ldquo;': '“', '&rdquo;': '”', '&eacute;': 'é',
};

/** Decode the handful of entities that actually show up in feed text. */
export function decodeEntities(input) {
  return String(input ?? '')
    .replace(/&#x([0-9a-f]+);/gi, (_, hex) => String.fromCodePoint(Number.parseInt(hex, 16)))
    .replace(/&#(\d+);/g, (_, dec) => String.fromCodePoint(Number.parseInt(dec, 10)))
    .replace(/&[a-z]+;/gi, (match) => ENTITIES[match.toLowerCase()] ?? match);
}

const textOf = (node) => {
  if (node === undefined || node === null) return '';
  if (typeof node === 'string' || typeof node === 'number') return decodeEntities(String(node)).trim();
  if (Array.isArray(node)) return textOf(node[0]);
  if (typeof node === 'object') {
    if (typeof node['#text'] === 'string') return decodeEntities(node['#text']).trim();
    if (typeof node['@_href'] === 'string') return decodeEntities(node['@_href']).trim();
    if (typeof node['@_url'] === 'string') return decodeEntities(node['@_url']).trim();
  }
  return '';
};

const attrOf = (node, name) => {
  if (!node || typeof node !== 'object') return '';
  if (Array.isArray(node)) return attrOf(node[0], name);
  return typeof node[`@_${name}`] === 'string' ? node[`@_${name}`].trim() : '';
};

/**
 * Fetch + parse an RSS feed. This is the whole point of podcasts being "open":
 * the feed itself carries the mp3 enclosure, so no third-party resolver needed.
 */
export async function fetchFeed(feedUrl, { timeoutMs = 15_000 } = {}) {
  if (!/^https?:\/\//i.test(String(feedUrl ?? ''))) {
    throw new UpstreamError('feedUrl must be an absolute http(s) URL', { provider: 'rss', status: 400 });
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  let response;
  try {
    response = await fetch(feedUrl, {
      headers: {
        Accept: 'application/rss+xml, application/xml, text/xml;q=0.9, */*;q=0.8',
        'User-Agent': 'PodWave/1.0 (+https://example.com/bot)',
      },
      signal: controller.signal,
      redirect: 'follow',
    });
  } catch (error) {
    clearTimeout(timer);
    const message = error?.name === 'AbortError' ? 'feed request timed out' : error.message;
    throw new UpstreamError(`Could not load feed: ${message}`, { provider: 'rss' });
  }
  clearTimeout(timer);

  if (!response.ok) {
    throw new UpstreamError(`Feed returned HTTP ${response.status}`, { provider: 'rss', status: response.status });
  }

  const xml = await response.text();
  return parseFeed(xml, response.url || feedUrl);
}

export function parseFeed(xml, feedUrl) {
  let doc;
  try {
    doc = parser.parse(xml);
  } catch (error) {
    throw new UpstreamError(`Feed is not valid XML: ${error.message}`, { provider: 'rss' });
  }

  const channel = doc?.rss?.channel || doc?.['rdf:RDF']?.channel || doc?.feed;
  if (!channel) {
    throw new UpstreamError('Feed has no <channel> element', { provider: 'rss' });
  }

  const channelImage =
    textOf(channel['itunes:image']) ||
    textOf(channel.image?.url) ||
    textOf(channel.image) ||
    attrOf(channel['itunes:image'], 'href');

  const feed = {
    title: stripHtml(textOf(channel.title), 300),
    description: stripHtml(textOf(channel.description) || textOf(channel['itunes:summary']) || textOf(channel.subtitle)),
    link: textOf(channel.link) || attrOf(channel.link, 'href'),
    feedUrl,
    language: textOf(channel.language) || null,
    author: stripHtml(
      textOf(channel['itunes:author']) || textOf(channel.author) || textOf(channel.managingEditor) || textOf(channel['dc:creator']),
      200,
    ),
    artwork: channelImage || null,
    explicit: /^(yes|true|explicit)$/i.test(textOf(channel['itunes:explicit'])),
    categories: asArray(channel['itunes:category']).map((c) => attrOf(c, 'text')).filter(Boolean),
  };

  const episodes = asArray(channel.item).map((item, index) => {
    const enclosures = asArray(item.enclosure);
    // Pick the first audio enclosure: some feeds list images first.
    const audio =
      enclosures.find((enclosure) => /^audio\//i.test(attrOf(enclosure, 'type')) || !!attrOf(enclosure, 'url')) || null;
    const audioUrl = attrOf(audio, 'url');
    const durationRaw = textOf(item['itunes:duration']);
    const published = toIso(textOf(item.pubDate) || textOf(item.published) || textOf(item.updated) || textOf(item['dc:date']));
    const episodeArtwork = attrOf(item['itunes:image'], 'href') || textOf(item['itunes:image']);

    return {
      index,
      guid: textOf(item.guid) || textOf(item.id) || audioUrl || `${feedUrl}#${index}`,
      title: stripHtml(textOf(item.title), 300) || `Episode ${index + 1}`,
      description: stripHtml(
        textOf(item['itunes:summary']) ||
          textOf(item['content:encoded']) ||
          textOf(item.description) ||
          textOf(item['itunes:subtitle']) ||
          textOf(item.summary),
        1200,
      ),
      audioUrl: /^https?:\/\//i.test(audioUrl) ? audioUrl : null,
      audioType: attrOf(audio, 'type') || null,
      audioBytes: Number.parseInt(attrOf(audio, 'length'), 10) || 0,
      durationSec: parseDuration(durationRaw),
      publishedAt: published,
      artwork: episodeArtwork ? episodeArtwork.replace(/^\/\//, 'https://') : null,
      episodeNumber: Number.parseInt(textOf(item['itunes:episode']), 10) || null,
      season: Number.parseInt(textOf(item['itunes:season']), 10) || null,
      explicit: /^(yes|true|explicit)$/i.test(textOf(item['itunes:explicit'])),
      link: textOf(item.link) || attrOf(item.link, 'href') || null,
      transcriptUrl:
        asArray(item['podcast:transcript']).map((t) => attrOf(t, 'url')).find(Boolean) || null,
      chaptersUrl: textOf(item['podcast:chapters']) || attrOf(item['podcast:chapters'], 'url') || null,
    };
  });

  return { feed, episodes };
}
