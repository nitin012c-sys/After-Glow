import { config } from '../config.js';
import { cache } from '../cache.js';
import { fetchJson, qs, clamp, BadRequestError } from '../http.js';
import { artworkFrom, makeTrack, parseDuration } from '../normalize.js';

/**
 * Jamendo - free, legal, full-length MP3.
 * Docs: https://developer.jamendo.com/v3.0/tracks
 * Auth: `client_id` query parameter (no signing).
 * Response is wrapped: { headers: {...}, results: [...] }
 *
 * `format=jsonpretty` + `audioformat=mp32` gives a 192kbps mp3 in `audio`.
 * Each track also carries its Creative Commons license via `license_ccurl`.
 */
const requireClient = () => {
  if (!config.jamendo.clientId) {
    throw new BadRequestError('Jamendo is not configured. Set JAMENDO_CLIENT_ID in .env (free at https://devportal.jamendo.com).');
  }
};

function mapTrack(raw) {
  return makeTrack({
    id: `jamendo:${raw.id}`,
    source: 'jamendo',
    kind: 'music',
    title: raw.name,
    subtitle: raw.album_name || '',
    artist: raw.artist_name || '',
    album: raw.album_name || '',
    artwork: artworkFrom(raw.image, raw.album_image),
    durationSec: Number.parseInt(raw.duration, 10) || 0,
    publishedAt: raw.releasedate ? new Date(`${raw.releasedate}T00:00:00Z`).toISOString() : null,
    audioUrl: raw.audio || null,
    downloadUrl: raw.audiodownload_allowed ? raw.audiodownload || null : null,
    license: raw.license_ccurl || null,
    language: raw.lang || null,
    links: {
      self: `/api/tracks/jamendo/${raw.id}`,
      webpage: raw.shareurl || null,
      artist: raw.artist_id ? `https://www.jamendo.com/artist/${raw.artist_id}` : null,
    },
    meta: {
      jamendoId: raw.id,
      artistId: raw.artist_id,
      albumId: raw.album_id,
      genre: raw.genre || null,
      tempo: raw.speed || null,
      vocalinstrumental: raw.vocalinstrumental || null,
      audiodownloadAllowed: Boolean(raw.audiodownload_allowed),
    },
  });
}

export async function search({ q, limit = 20, offset = 0, tags = [], order = 'relevance', vocalinstrumental }) {
  requireClient();
  const safeLimit = clamp(Number(limit) || 20, 1, 200);
  const safeOffset = Math.max(0, Number(offset) || 0);
  const key = `jamendo:search:${q}:${safeLimit}:${safeOffset}:${tags.join('|')}:${order}:${vocalinstrumental || ''}`;

  return cache.wrap(key, config.cacheTtl.search, async () => {
    const url = `${config.jamendo.baseUrl}/tracks/?${qs({
      client_id: config.jamendo.clientId,
      format: 'jsonpretty',
      limit: safeLimit,
      offset: safeOffset,
      search: q || undefined,
      tags: tags.length ? tags : undefined,
      order: q ? 'relevance' : order || 'popularity_month',
      audioformat: 'mp32',
      imagesize: 500,
      include: 'musicinfo',
      fullcount: 'true',
      vocalinstrumental,
    })}`;

    const body = await fetchJson(url, { provider: 'jamendo' });
    const results = Array.isArray(body?.results) ? body.results : [];
    const total = Number.parseInt(body?.headers?.results_fullcount, 10) || results.length;

    return { tracks: results.map(mapTrack), total };
  });
}

export async function getTrack(id) {
  requireClient();
  const key = `jamendo:track:${id}`;
  return cache.wrap(key, config.cacheTtl.track, async () => {
    const url = `${config.jamendo.baseUrl}/tracks/?${qs({
      client_id: config.jamendo.clientId,
      format: 'jsonpretty',
      id,
      audioformat: 'mp32',
      imagesize: 500,
      include: 'musicinfo',
    })}`;
    const body = await fetchJson(url, { provider: 'jamendo' });
    const raw = body?.results?.[0];
    if (!raw) throw new BadRequestError(`Jamendo track ${id} not found`);
    return mapTrack(raw);
  });
}

/** Genre browsing - useful for a "Discover" shelf without a search term. */
export async function featured({ limit = 20, tags = [] } = {}) {
  return search({ q: '', limit, tags, order: 'popularity_month' });
}

export const jamendoDuration = parseDuration;
