import express from 'express';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { config, providerStatus } from './src/config.js';
import { cache } from './src/cache.js';
import { searchRouter } from './src/routes/search.js';
import { tracksRouter } from './src/routes/tracks.js';
import { podcastsRouter } from './src/routes/podcasts.js';
import { streamRouter } from './src/routes/stream.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();

app.disable('x-powered-by');
app.set('trust proxy', 1);

/* ------------------------------- middleware ------------------------------ */
app.use(
  cors({
    origin: config.corsOrigins.includes('*') ? true : config.corsOrigins,
    methods: ['GET', 'HEAD', 'OPTIONS'],
    maxAge: 86400,
  }),
);

app.use(
  rateLimit({
    windowMs: config.rateLimit.windowMs,
    max: config.rateLimit.max,
    standardHeaders: true,
    legacyHeaders: false,
    // The audio proxy is exempt: a seek-heavy session would otherwise 429.
    skip: (req) => req.path.startsWith('/api/stream'),
    message: { ok: false, error: { message: 'Too many requests, slow down.' } },
  }),
);

app.use((req, res, next) => {
  const started = Date.now();
  res.on('finish', () => {
    const ms = Date.now() - started;
    if (config.nodeEnv !== 'test') console.log(`${res.statusCode} ${req.method} ${req.originalUrl} ${ms}ms`);
  });
  next();
});

/* --------------------------------- routes -------------------------------- */
app.get('/', (req, res) => {
  res.json({
    name: 'PodWave API',
    version: '1.0.0',
    docs: '/api',
    health: '/health',
    demoPlayer: '/demo',
  });
});

app.get('/health', (req, res) => {
  res.json({
    ok: true,
    uptimeSec: Math.round(process.uptime()),
    providers: providerStatus(),
    streamProxy: config.proxy.enabled,
    cache: cache.stats(),
  });
});

app.get('/api', (req, res) => {
  res.json({
    ok: true,
    endpoints: {
      search: [
        'GET /api/search?q=...&sources=podcasts,music,youtube&limit=20',
        'GET /api/search/podcasts?q=...',
        'GET /api/search/music?q=...  |  ?tags=chill,acoustic',
        'GET /api/search/youtube?q=...',
      ],
      podcasts: [
        'GET /api/podcasts/search?q=...',
        'GET /api/podcasts/:source/:id/episodes?limit=20&offset=0   (source: podcastindex|listennotes)',
        'GET /api/rss?url=<feed>&limit=20',
        'GET /api/rss/discover?url=<website>',
      ],
      tracks: [
        'GET /api/track/:id            (jamendo:123 | podcastindex:456 | youtube:abc)',
        'GET /api/tracks/:source/:id',
        'GET /api/resolve?url=<youtube or audio url>',
        'GET /api/providers',
      ],
      media: ['GET /api/stream?url=<encoded audio url>   (Range-aware proxy)'],
    },
    providers: providerStatus(),
  });
});

app.use('/api', searchRouter);
app.use('/api', tracksRouter);
app.use('/api', podcastsRouter);
app.use('/api', streamRouter);
app.use('/demo', express.static(path.join(__dirname, 'public')));

/* ------------------------------ error handler ---------------------------- */
app.use((req, res) => {
  res.status(404).json({ ok: false, error: { message: `No route for ${req.method} ${req.originalUrl}`, status: 404 } });
});

// eslint-disable-next-line no-unused-vars
app.use((error, req, res, next) => {
  const status = error.status || (error.expose ? 400 : 500);
  if (status >= 500) console.error('[error]', error);

  res.status(status).json({
    ok: false,
    error: {
      message: error.expose ? error.message : 'Internal server error',
      provider: error.provider || undefined,
      status,
    },
  });
});

if (process.env.NODE_ENV !== 'test') {
  app.listen(config.port, () => {
    const active = Object.entries(providerStatus())
      .filter(([, on]) => on)
      .map(([name]) => name);
    console.log(`\n  PodWave API listening on http://localhost:${config.port}`);
    console.log(`  Active providers: ${active.join(', ') || 'none (add keys to .env)'}`);
    console.log(`  Demo player:      http://localhost:${config.port}/demo\n`);
  });
}

export default app;
